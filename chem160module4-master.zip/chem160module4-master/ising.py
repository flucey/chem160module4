from random import choice
n=8
# Initialize all spin up case
## Add line here from lecture notes
# Calculate the system energy
## Add lines here from lecture notes
print("<E>=%4.2f"%(float(energy)/(n*n)))
# Check this result before continuing
#
# Initialize random spin case (copy & edit the code given above)
## Add line here from lecture notes
# Calculate the system energy
## Add lines here from lecture notes (or copy from above)
print("<E>=%4.2f"%(float(energy)/(n*n)))

#Print out ising model
## Add lines here from lecture notes
